<?php 

	return array(
	
	// Database
			'db_host'       => 'HOST', 
			'db_name'       => 'DATABASE NAME', 
			'db_user'       => 'USER', 
			'db_password'   => 'PASS',
			
	 // Sender of all emails sent
	 'mail'    => 'Sender of all emails ie: no-reply@gmail.com', 
	 'name'    => 'Name of Sender ie: ShotPro', 
	);