<!-- Bootstrap core JavaScript 
    ================================================== -->    
    {{ HTML::script('public/js/jquery.min.js') }}
    {{ HTML::script('public/js/jquery.easing.1.3.js') }}
    {{ HTML::script('public/js/jquery-ui-1.10.3.custom.min.js') }}
    {{ HTML::script('public/js/jquery.ui.touch-punch.min.js') }}
    {{ HTML::script('public/js/bootstrap.min.js') }}
    {{ HTML::script('public/js/bootstrap-switch.js') }}
    {{ HTML::script('public/js/tooltip.js') }}
    {{ HTML::script('public/js/popover.js') }}
    {{ HTML::script('public/js/flatui-checkbox.js') }}
    {{ HTML::script('public/js/jquery.autosize.min.js') }}
    {{ HTML::script('public/js/mentions_links.js') }}
    {{ HTML::script('public/js/jqueryTimeago.js') }}
    {{ HTML::script('public/js/bootbox.min.js') }}
    {{ HTML::script('public/js/jquery.fs.picker.min.js') }}
    {{ HTML::script('public/js/count.js') }}
    {{ HTML::script('public/js/functions.js') }}
    {{ HTML::script('public/js/jquery.form.js') }}
    
    