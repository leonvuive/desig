<div class="col-md-4">
    		
    		<div class="panel panel-default">
            <div class="panel-heading">
              <h3 class="panel-title text-center"><strong>Advertising</strong></h3>
            </div>
            <div class="panel-body">
            	<a href="#">
            		<img class="ad-img btn-block" src="{{ URL::asset('public/ad/ad_258_200.png') }}">
            	</a>
            </div>
          </div>
          
    </div><!-- /End col-md-4 -->