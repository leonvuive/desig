<?php
class Followers extends Eloquent {

	protected $guarded = array();
	public $timestamps = false;
		
}