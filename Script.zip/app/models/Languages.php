<?php
class Languages extends Eloquent {

	protected $guarded = array();
	public $timestamps = false;
}