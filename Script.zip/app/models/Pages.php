<?php
class Pages extends Eloquent {

	protected $guarded = array();
	public $timestamps = false;
}