<?php
class AdminSettings extends Eloquent {

	protected $guarded = array();
	public $timestamps = false;
}